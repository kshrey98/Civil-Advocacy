package com.example.civiladvocacyapp;

import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.List;

public class RVAdapter extends RecyclerView.Adapter<RVOfficialViewItemHolder> {
    private final MainActivity mainActivity;
    List<Offices> officesList;
    List<Officials> officialsList;


    public RVAdapter(MainActivity mainActivity, List<Offices> officesList, List<Officials> officialsList) {
        this.mainActivity = mainActivity;
        this.officesList = officesList;
        this.officialsList = officialsList;
    }

    @NonNull
    @Override
    public RVOfficialViewItemHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View items = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.official_details_item_view, parent, false);
        items.setOnClickListener(mainActivity);
        return new RVOfficialViewItemHolder(items);
    }

    @Override
    public void onBindViewHolder(@NonNull RVOfficialViewItemHolder holder, int position) {
        Officials official = officialsList.get(position);
        if(official.getTitle() != null){
            holder.officesName.setText(official.getTitle());
        }
        holder.officials.setText(official.getName()+official.getParty());

//        if (!official.getPhotoUrl().isEmpty()) {
//            pullImageFromURL(holder,official.getPhotoUrl());
//        } else {
//            holder.imageView_of_Official_main_activity.setImageResource(R.drawable.missing);
//        }


        if(official.getPhotoUrl().trim().equals("")){
            Picasso.get().load("temp")
                    .error(R.drawable.missing)
                    .into(holder.imageView_of_Official_main_activity);
        } else {
            String url = official.getPhotoUrl().trim().replace("http:","https:");
            Picasso.get().load(url)
                    .error(R.drawable.brokenimage)
                    .into(holder.imageView_of_Official_main_activity);
        }

    }

    public void pullImageFromURL(@NonNull RVOfficialViewItemHolder holder, String url_to_img) {


        if (url_to_img != null) {
            Picasso picasso = new Picasso.Builder(mainActivity).listener(new Picasso.Listener() {

                @Override
                public void onImageLoadFailed(Picasso picasso, Uri uri, Exception exception) {
                    final String url_to_img_changed = url_to_img.replace("http:", "https:");

                    picasso.load(url_to_img_changed)
                            .error(R.drawable.brokenimage)
                            .into(holder.imageView_of_Official_main_activity);

                }
            }).build();

            picasso.load(url_to_img)
                    .error(R.drawable.brokenimage)
                    .into(holder.imageView_of_Official_main_activity);
            picasso.setLoggingEnabled(true);
        }
    }

    @Override
    public int getItemCount() {
        return officialsList.size();
    }
}
