package com.example.civiladvocacyapp;

import android.content.Intent;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.squareup.picasso.Picasso;

public class PhotoActivity extends AppCompatActivity {

    TextView currentLocation, officesNames, officialsName;
    ImageView official_image,partyLogo;
    String partyurl;
    // ConstraintLayout constraintLayout;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setTitle("Civil Advocacy");
        setContentView(R.layout.activity_photo_detail);
        partyurl="";
        currentLocation = findViewById(R.id.text_view_location_photo_detail);
        officesNames = findViewById(R.id.text_view_position_of_official_photo_activity);
        officialsName = findViewById(R.id.text_view_name_of_official_photo_activity);
        official_image = findViewById(R.id.image_view_official_photo_activity);
        partyLogo = findViewById(R.id.image_view_official_party_photo_activity);
        //  constraintLayout = findViewById(R.id.constrainedLayout);

        Intent photoIntent = getIntent();

        if(photoIntent.hasExtra("location")){
            String location = photoIntent.getStringExtra("location");
            currentLocation.setText(location);
        }
        if(photoIntent.hasExtra("title")){
            officesNames.setText(photoIntent.getStringExtra("title"));
        }
        if(photoIntent.hasExtra("name")){
            officialsName.setText(photoIntent.getStringExtra("name"));
        }
        if(photoIntent.hasExtra("url")){
            Picasso.get().load(photoIntent.getStringExtra("url"))
                    .error(R.drawable.brokenimage)
                    .into(official_image);
        }
        if(photoIntent.hasExtra("partyLogo")){
            this.partyurl = photoIntent.getStringExtra("partyLogo");
            if(photoIntent.getStringExtra("partyLogo").contains("democratic")){
                partyLogo.setImageResource(R.drawable.dem_logo);
                //constraintLayout.setBackgroundResource(R.color.blue);
                //findViewById(R.id.layout_official).setBackgroundColor(Color.RED);
                findViewById(R.id.details_layout_photo_detail).setBackgroundColor(Color.BLUE);

                partyLogo.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://democrats.org"));
                        startActivity(intent);
                    }
                });
                // String party_name = this.partyurl;



            } else if(photoIntent.getStringExtra("partyLogo").contains("republican")){
                partyLogo.setImageResource(R.drawable.rep_logo);
                //constraintLayout.setBackgroundResource(R.color.red);
                findViewById(R.id.details_layout_photo_detail).setBackgroundColor(Color.RED);

                partyLogo.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.gop.com"));
                        startActivity(intent);
                    }
                });
            } else {
                // constraintLayout.setBackgroundResource(R.color.dark_grey);
                findViewById(R.id.details_layout_photo_detail).setBackgroundColor(Color.BLACK);
            }
        }


    }

//    public void routeToPartyWebsite(View V){
//
//        Intent intent_to_browser = null;
//
//        if (this.partyurl.isEmpty())
//        {
//            String party_name = this.partyurl;
//
//            if (party_name.toLowerCase().contains("democratic")){
//                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://democrats.org"));
//                startActivity(intent);
//            } else if(party_name.toLowerCase().contains("republican")){
//                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.gop.com"));
//                startActivity(intent);
//            }
//
//
//        }
//        else
//        {
//            Toast.makeText(this, "Error in obtaining the details of official", Toast.LENGTH_LONG).show();
//        }
//
//
//    }

    public boolean hasNetworkConnection() {

        ConnectivityManager connectivityManager =  getSystemService(ConnectivityManager.class);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
        return (networkInfo != null && networkInfo.isConnectedOrConnecting());
    }
}
