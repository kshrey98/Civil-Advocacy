package com.example.civiladvocacyapp;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.RequestQueue;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;


import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private  String cividAdvocacyURL = "https://www.googleapis.com/civicinfo/v2/representatives";
    private static final String TAG = "MainActivity";
    private RequestQueue queue;
    private CivilAdvContainer civilAdvContainer;
    String address ;
    TextView currentLocation;
    RecyclerView recyclerView;
    NormalizedInput normalizedInput;
    ArrayList< Officials > officials;
    private FusedLocationProviderClient mFusedLocationClient;
    private static final int LOCATION_REQUEST = 111;
    private static String locationString = "Unspecified Location";
    boolean checkGPS = false;
    Double lat = 0.0 , longi = 0.0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        currentLocation = findViewById(R.id.text_view_location_main);
        recyclerView = findViewById(R.id.recycler_view_offical_list);

        mFusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        determineLocation();
        getAdvocacyData(address);
    }

    @SuppressLint("MissingPermission")
    private String determineLocation() {
        if (checkAppPermissions()) {
            mFusedLocationClient.getLastLocation()
                    .addOnSuccessListener(this, location -> {
                        // Got last known location. In some situations this can be null.
                        if (location != null) {
                            locationString = getPlace(location);
                            Log.d(TAG, "determineLocation: Location String "+ locationString);
                        }
                    })
                    .addOnFailureListener(this, e -> Toast.makeText(MainActivity.this,
                            e.getMessage(), Toast.LENGTH_LONG).show());
        }
        return locationString;
    }

    private boolean checkAppPermissions() {
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION) !=
                PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(this,
                    new String[]{
                            Manifest.permission.ACCESS_FINE_LOCATION
                    }, LOCATION_REQUEST);
            return false;
        }
        return true;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {

        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == LOCATION_REQUEST) {
            if (permissions[0].equals(Manifest.permission.ACCESS_FINE_LOCATION)) {
                if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    determineLocation();
                    getAdvocacyData(address);
                }
            }
        }
    }
    private String getPlace(Location loc) {

        StringBuilder sb = new StringBuilder();

        Geocoder geocoder = new Geocoder(this, Locale.getDefault());
        List<Address> addresses;

        try {
            addresses = geocoder.getFromLocation(loc.getLatitude(), loc.getLongitude(), 1);
            String city = addresses.get(0).getLocality();
            String state = addresses.get(0).getAdminArea();
            sb.append(String.format(
                    Locale.getDefault(),
                    "%s, %s", city, state));
            this.lat = loc.getLatitude();
            this.longi = loc.getLongitude();
            address = addresses.get(0).getAddressLine(0);
            getAdvocacyData(address);

        } catch (IOException e) {
            e.printStackTrace();
        }
        return sb.toString();
    }


    private void getAdvocacyData(String address) {
        if(hasNetworkConnection()){
            queue = Volley.newRequestQueue(getApplicationContext());
            // Building URL for API
            String url = Helper.buildURL(cividAdvocacyURL, address);
            JsonObjectRequest jsonObjectRequest =
                    new JsonObjectRequest(Request.Method.GET, url,
                            null, new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {
                            officials  = Helper.parseJSON(response.toString());
                            normalizedInput = Helper.normalizedInput(response.toString());
                            civilAdvContainer = new CivilAdvContainer(normalizedInput, null, officials);
                            setCivilAdvocacyData(civilAdvContainer);
                        }
                    }, new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            //Toast.makeText(MainActivity.this, "" + error.toString(), Toast.LENGTH_LONG).show();
                            Log.e(TAG, error.toString());
                        }
                    });
            // Add the request to the RequestQueue.
            queue.add(jsonObjectRequest);
        } else {
            currentLocation.setText("No Data For Location");
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle("No Network Connection");
            builder.setMessage("Data cannot be accessed/loaded without an internet connection.");
          /* builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {

               public void onClick(DialogInterface view) {
                   startActivity(new Intent(
                           Settings.ACTION_WIFI_SETTINGS));
               }
           });*/
            AlertDialog dialog = builder.create();
            dialog.show();

            //Toast.makeText(MainActivity.this, "No Network available" , Toast.LENGTH_LONG).show();
        }
    }

    private void setCivilAdvocacyData(CivilAdvContainer civilAdvContainer) {
        if(civilAdvContainer != null){
            if(civilAdvContainer.getNormalizedInputObject().getLine1().isEmpty()){
                currentLocation.setText(civilAdvContainer.getNormalizedInputObject().getCity() + ", " + civilAdvContainer.getNormalizedInputObject().getState());
            } else {
                String zipCode = civilAdvContainer.getNormalizedInputObject().getZip();
                currentLocation.setText(civilAdvContainer.getNormalizedInputObject().getLine1()+", "
                        + civilAdvContainer.getNormalizedInputObject().getCity() + ", "
                        + civilAdvContainer.getNormalizedInputObject().getState()+" "+zipCode);
            }
            RVAdapter advocacyAdapter = new RVAdapter(MainActivity.this, null, civilAdvContainer.getOfficials());
            recyclerView.setAdapter(advocacyAdapter);
            recyclerView.setLayoutManager(new LinearLayoutManager(MainActivity.this));
            advocacyAdapter.notifyDataSetChanged();

        } else{
            Toast.makeText(this, "No data found for your location", Toast.LENGTH_LONG).show();
        }

    }

    // Menu Items Functionality
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId() == R.id.menu_item_about){
            Intent aboutIntent = new Intent(this, AboutActivity.class);
            startActivity(aboutIntent);
            return true;
        }
        if(item.getItemId() == R.id.menu_item_location_search){
            changeLocation();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void changeLocation() {
        if(hasNetworkConnection()) {
            LayoutInflater inflater = LayoutInflater.from(this);
            final View view = inflater.inflate(R.layout.dialog_layout_location_search, null);
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle("Enter Address");
            builder.setView(view);

            builder.setPositiveButton("OK", (dialog, id) -> {
                EditText alertDialogLocation = view.findViewById(R.id.edit_text_location_search);
                address = alertDialogLocation.getText().toString();
                getAdvocacyData(address);
            });


            builder.setNegativeButton("CANCEL", (dialog, id) -> {
                Toast.makeText(MainActivity.this, "Need to search for a new location?",
                        Toast.LENGTH_SHORT).show();
            });
            AlertDialog dialog = builder.create();

            dialog.show();
        } else {
            Toast.makeText(this, "No Network Connection", Toast.LENGTH_SHORT).show();

        }
    }

    @Override
    public void onClick(View view) {
        int position = recyclerView.getChildAdapterPosition(view);
        Officials officials =  this.officials.get(position);
        Intent in = new Intent(this, OfficialActivity.class);
        in.putExtra("officials", officials);
        in.putExtra("locationName", civilAdvContainer.getNormalizedInputObject());
        view.getContext().startActivity(in);
    }

    public boolean hasNetworkConnection() {

        ConnectivityManager connectivityManager =  getSystemService(ConnectivityManager.class);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
        return (networkInfo != null && networkInfo.isConnectedOrConnecting());
    }


}