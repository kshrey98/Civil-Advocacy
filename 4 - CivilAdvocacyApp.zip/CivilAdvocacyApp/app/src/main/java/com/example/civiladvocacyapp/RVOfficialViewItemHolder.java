package com.example.civiladvocacyapp;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class RVOfficialViewItemHolder extends RecyclerView.ViewHolder {
    TextView officesName, officials;
    ImageView imageView_of_Official_main_activity;
    public RVOfficialViewItemHolder(@NonNull View itemView) {
        super(itemView);
        officesName = itemView.findViewById(R.id.text_view_office_name);
        officials = itemView.findViewById(R.id.text_view_official_name_party);
        imageView_of_Official_main_activity = itemView.findViewById(R.id.image_view_list_item);

    }
}

