package com.example.civiladvocacyapp;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.text.util.Linkify;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;


import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class OfficialActivity extends AppCompatActivity {

    NormalizedInput normalizedInput;
    Officials officials;
    TextView currentLocation, officesNames, officialsName, officialsParty;
    TextView address, addressDetails, phone, phoneDetails, website, websiteDetails, email , emailDetails;
    ImageView official_image, partyLogo, facebookIcon, twitterIcon, youtubeIcon;
    ConstraintLayout constraintLayout;
    Channel facebook, youtube, twitter;
    String location = "";
    String location_intent = "";
    String title_intent = "";
    String name_intent = "";
    String finalUrl_intent = "";
    String party_logo_intent = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_official);

        currentLocation = findViewById(R.id.text_view_location_official);

        officesNames = findViewById(R.id.text_view_pos_of_official);
        officialsName = findViewById(R.id.text_view_name_of_official);
        officialsParty = findViewById(R.id.text_view_party_of_official);
        official_image = findViewById(R.id.image_view_official_photo_official_activity);

        address = findViewById(R.id.text_view_address);
        addressDetails = findViewById(R.id.text_view_address_of_official);

        // Phone
        phone = findViewById(R.id.text_view_phone);
        phoneDetails = findViewById(R.id.text_view_phone_of_official);

        // Emails
        email = findViewById(R.id.text_view_email);
        emailDetails = findViewById(R.id.text_view_email_of_official);

        // Website
        website = findViewById(R.id.text_view_website);
        websiteDetails = findViewById(R.id.text_view_website_of_official);

        partyLogo = findViewById(R.id.image_view_official_party_photo_official_activity);

        //constraintLayout = findViewById(R.id.constrainedLayout);

        facebookIcon = findViewById(R.id.image_view_facebook);
        twitterIcon = findViewById(R.id.image_view_twitter);
        youtubeIcon = findViewById(R.id.image_view_youtube);

        youtubeIcon.setVisibility(View.INVISIBLE);
        facebookIcon.setVisibility(View.INVISIBLE);
        youtubeIcon.setVisibility(View.INVISIBLE);

        Intent civilIntent = getIntent();
        if(civilIntent.hasExtra("locationName")){
            this.normalizedInput = (NormalizedInput)civilIntent.getSerializableExtra("locationName");

            if(!normalizedInput.getLine1().isEmpty()){
                location = normalizedInput.getLine1() + ", " + normalizedInput.getCity()+", "+normalizedInput.getState() + " " + normalizedInput.getZip();
            } else {
                location = normalizedInput.getCity()+", "+normalizedInput.getState();
            }

            this.currentLocation.setText(location);
        }
        if(civilIntent.hasExtra("officials")){
            this.officials = (Officials) civilIntent.getSerializableExtra(String.valueOf("officials"));
            setOfficialsData(officials);
        }

    }

    private void setOfficialsData(Officials officials) {
        String title =officials.getTitle() ;
        String name = officials.getName();
        String party = officials.getParty();

        officesNames.setText(title);
        officialsName.setText(name);
        officialsParty.setText(party);
        String url = "";

        if(officials.getPhotoUrl().trim().equals("")){
            Picasso.get().load("temp")
                    .error(R.drawable.missing)
                    .into(official_image);
        } else {
            url = officials.getPhotoUrl().trim().replace("http:","https:");
            Picasso.get().load(url)
                    .error(R.drawable.brokenimage)
                    .into(official_image);
        }

        String finalUrl = url;
        if(!officials.getPhotoUrl().isEmpty()){
            location_intent = location;
            title_intent = title;
            name_intent = name;
            finalUrl_intent = finalUrl;
            party_logo_intent = officials.getParty().trim().toLowerCase();


//            official_image.setOnClickListener(new View.OnClickListener() {
//                @Override
//                public void onClick(View view) {
//
//                    Intent photoIntent = new Intent(IndividualOfficials.this, PhotoActivity.class);
//
//
//
//
//
//                    photoIntent.putExtra("location", location);
//                    photoIntent.putExtra("title", title);
//                    photoIntent.putExtra("name", name);
//                    photoIntent.putExtra("url", finalUrl);
//                    photoIntent.putExtra("partyLogo",officials.getParty().trim().toLowerCase());
//
//                    startActivity(photoIntent);
//                }
//            });
        }

        // Setting address Details
        if(!officials.getAddress().isEmpty()){
            //address.setTextColor(Color.BLACK);
            addressDetails.setText(officials.getAddress());

            Linkify.addLinks(addressDetails, Linkify.ALL);
            addressDetails.setTextColor(Color.WHITE);
        } else {
            address.setVisibility(View.GONE);
            addressDetails.setVisibility(View.GONE);
        }

        // Phone Details
        if(!officials.getPhones().isEmpty()){

            phoneDetails.setText(officials.getPhones());
            phoneDetails.setTextColor(Color.BLACK);
            Linkify.addLinks(phoneDetails, Linkify.ALL);
        } else {
            phone.setVisibility(View.GONE);
            phoneDetails.setVisibility(View.GONE);
        }

        // Emails
        if(!officials.getEmails().isEmpty()){

            emailDetails.setText(officials.getEmails());
            emailDetails.setTextColor(Color.BLACK);
            Linkify.addLinks(emailDetails, Linkify.ALL);
            emailDetails.setLinkTextColor(Color.WHITE);
        } else {
            email.setVisibility(View.GONE);
            emailDetails.setVisibility(View.GONE);
        }

        // Website
        if(!officials.getUrls().isEmpty()){

            websiteDetails.setText(officials.getUrls());
            websiteDetails.setTextColor(Color.BLACK);
            Linkify.addLinks(websiteDetails, Linkify.ALL);
        } else {
            website.setVisibility(View.GONE);
            websiteDetails.setVisibility(View.GONE);
        }

        if(officials.getParty().trim().toLowerCase().contains("democratic")){
            //currentLocation.setBackgroundResource(R.color.lightTheme);
            partyLogo.setImageResource(R.drawable.dem_logo);
            //constraintLayout.setBackgroundResource(R.color.blue);
            findViewById(R.id.layout_official).setBackgroundColor(Color.BLUE);
            // getWindow().setNavigationBarColor(getColor(R.color.blue));
        } else if(officials.getParty().trim().toLowerCase().contains("republican")){
            //currentLocation.setBackgroundResource(R.color.lightTheme);
            partyLogo.setImageResource(R.drawable.rep_logo);
            //constraintLayout.setBackgroundResource(R.color.red);
            findViewById(R.id.layout_official).setBackgroundColor(Color.RED);
            // getWindow().setNavigationBarColor(getColor(R.color.red));
        } else if(officials.getParty().trim().toLowerCase().contains("nonpartisan")) {
            // currentLocation.setBackgroundResource(R.color.lightTheme);
            //constraintLayout.setBackgroundResource(R.color.dark_grey);
            //getWindow().setNavigationBarColor(getColor(R.color.dark_grey));
            findViewById(R.id.layout_official).setBackgroundColor(Color.BLACK);
            partyLogo.setVisibility(View.INVISIBLE);
        }



        setChannels(officials.getChannels());
    }

    private void setChannels(ArrayList<Channel> channels) {
        int channelSize = channels.size();
        if(channelSize != 0){
            for(Channel single_channel : channels ) {
                if(single_channel.getType().equals("Facebook")) {
                    facebook = single_channel;
                    if (single_channel.getId().isEmpty())
                    {
                        facebookIcon.setVisibility(View.INVISIBLE);
                    }

//                    if(facebookIcon.getVisibility() == View.GONE){
//                        facebookIcon.setVisibility(View.INVISIBLE);
//                        continue;
//                    } else {
//                        facebookIcon.setVisibility(View.VISIBLE);
//                    }

                    else
                    {
                        facebookIcon.setVisibility(View.VISIBLE);

                        facebookIcon.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                Intent intent = null;
                                String name = single_channel.getId();
                                try {
                                    // get the Facebook app if possible
                                    getPackageManager().getPackageInfo("com.facebook.katana", 0);
                                    String FACEBOOK_URL = "https://www.facebook.com/" + name;
                                    intent = new Intent(Intent.ACTION_VIEW, Uri.parse("fb://facewebmodal/f?href=" + FACEBOOK_URL));
                                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                } catch (Exception e) {         // no Twitter app, revert to browser
                                    intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://facebok.com/" + name));
                                }
                                startActivity(intent);
                            }
                        }); }
                }
                if(single_channel.getType().equals("Twitter")) {
                    twitter = single_channel;
                    //twitterIcon.setVisibility(View.VISIBLE);
                    if (single_channel.getId().isEmpty()) {
                        twitterIcon.setVisibility(View.INVISIBLE);
                    }
                    // if (twitterIcon.getVisibility() == View.GONE) {
                    //   continue;
                    // }
                    else {
                        twitterIcon.setVisibility(View.VISIBLE);
                        // }

                        twitterIcon.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                Intent intent = null;
                                String name = single_channel.getId();
                                try {
                                    // get the Twitter app if possible
                                    getPackageManager().getPackageInfo("com.twitter.android", 0);
                                    intent = new Intent(Intent.ACTION_VIEW, Uri.parse("twitter://user?screen_name=" + name));
                                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                } catch (Exception e) {         // no Twitter app, revert to browser
                                    intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://twitter.com/" + name));
                                }
                                startActivity(intent);
                            }
                        });

                    }
                }
                if(single_channel.getType().equals("YouTube")) {
                    youtube = single_channel;
                    //youtubeIcon.setVisibility(View.VISIBLE);
                    Toast.makeText(this, "s" + single_channel.getId(), Toast.LENGTH_SHORT).show();
                    if (single_channel.getId().isEmpty()) {
                        youtubeIcon.setVisibility(View.INVISIBLE);
                    }
//                    if(youtubeIcon.getVisibility() == View.GONE){
//                        continue;
//                    }
                    else {
                        youtubeIcon.setVisibility(View.VISIBLE);

                        youtubeIcon.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                String name = single_channel.getId();
                                Intent intent = null;
                                try {
                                    intent = new Intent(Intent.ACTION_VIEW);
                                    intent.setPackage("com.google.android.youtube");
                                    intent.setData(Uri.parse("https://www.youtube.com/" + name));
                                    startActivity(intent);

                                } catch (ActivityNotFoundException e) {
                                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/" + name)));
                                }
                            }
                        });
                    }
                }
            }
        }
    }



    public void routeToPhotoActivity(View v) {
        if(officials.getParty()!= null){
//            Intent intent_to_photo_detail_activity = new Intent(this, PhotoActivity.class);
//            intent_to_photo_detail_activity.putExtra("LOCATION_OF_THE_OFFICIAL", location_searched);
//            intent_to_photo_detail_activity.putExtra("OFFICIAL_INFO", main_details_of_official_item);
//            startActivity(intent_to_photo_detail_activity);

            Intent photoIntent = new Intent(OfficialActivity.this, PhotoActivity.class);





            photoIntent.putExtra("location", location_intent);
            photoIntent.putExtra("title", title_intent);
            photoIntent.putExtra("name", name_intent);
            photoIntent.putExtra("url", finalUrl_intent);
            photoIntent.putExtra("partyLogo",party_logo_intent);

            startActivity(photoIntent);
        }
    }

    public boolean hasNetworkConnection() {

        ConnectivityManager connectivityManager =  getSystemService(ConnectivityManager.class);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
        return (networkInfo != null && networkInfo.isConnectedOrConnecting());
    }

    public void routeToPartyWebsite(View v) {
        if (officials.getParty().toLowerCase().contains("democratic")){
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://democrats.org"));
            startActivity(intent);
        } else if(officials.getParty().toLowerCase().contains("republican")){
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.gop.com"));
            startActivity(intent);
        }
    }

}